/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package codigo;

import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
/**
 *
 * @author MÁYRA NUNES
 */

public class Principal {
    public static void main(String[] args) {
        String nomemusica, nomeAlbum, nomeArtista, nomeGenero;
       
      /*
                //inserção de 1 Gênero no SGBD
                Genero_Musical g1 = new Genero_Musical("Internacional");
		if(Conexao.inserirgenero(g1)!=0) {
                    System.out.println("Gênero inserido com sucesso no banco!");
		} else {
                    System.out.println("Erro na inserção!");
                    
		}
                // inserção de um Artista;
                Artista a = new Artista("Third Day");
                
		if(Conexao.inserirArtista(a)!=0) {
                    System.out.println("Artista inserido com sucesso no banco!");
		} else {
                    System.out.println("Erro na inserção!");
		}
                // inserção de um album
                Album b1 = new Album ("Offerings", 2010);
                
		if(Conexao.inseriralbum(b1)!=0) {
                    System.out.println("Album inserido com sucesso no banco!");
		} else {
                    System.out.println("Erro na inserção do Album!");
		}
                
		// inserção de  Musica no SGBD
		
		Musica y = new Musica("Agnus Day", 300, 10);
               
		if(Conexao.inserirmusica(y)!=0) {
                    System.out.println("Musica inserida com sucesso no banco!");
		} else {
                    System.out.println("Erro na inserção!");
		}
                
                //inserção de mais um Gênero no SGBD
                Genero_Musical g2 = new Genero_Musical("Católica");
		if(Conexao.inserirgenero(g2)!=0) {
                    System.out.println("Gênero inserido com sucesso no banco!");
		} else {
                    System.out.println("Erro na inserção!");
                    
		}
                // inserção de mais um Artista;
                Artista a1 = new Artista("Rosa de Saron");
                
		if(Conexao.inserirArtista(a1)!=0) {
                    System.out.println("Artista inserido com sucesso no banco!");
		} else {
                    System.out.println("Erro na inserção!");
		}
                // inserção de mais um album
                Album b2 = new Album ("Agora e o Eterno", 2012);
		if(Conexao.inseriralbum(b1)!=0) {
                    System.out.println("Album inserido com sucesso no banco!");
		} else {
                    System.out.println("Erro na inserção do Album!");
		}
                
		// inserção de mais uma Musica no SGBD
		Musica y1 = new Musica("Até o  fim", 300, 10);
               
		if(Conexao.inserirmusica(y1)!=0) {
                    System.out.println("Musica inserida com sucesso no banco!");
		} else {
                    System.out.println("Erro na inserção!");
		}
                
                // inserção de outra Musica no SGBD
		               
                //inserção de mais um Gênero no SGBD
                Genero_Musical g3 = new Genero_Musical("Católica");
		if(Conexao.inserirgenero(g3)!=0) {
                    System.out.println("Gênero inserido com sucesso no banco!");
		} else {
                    System.out.println("Erro na inserção!");
                    
		}
                // inserção de mais um Artista;
                Artista a2 = new Artista("Rosa de Saron");
                
		if(Conexao.inserirArtista(a2)!=0) {
                    System.out.println("Artista inserido com sucesso no banco!");
		} else {
                    System.out.println("Erro na inserção!");
		}
                // inserção de mais um album
                Album b3 = new Album ("Agora e o Eterno", 2015);
		if(Conexao.inseriralbum(b3)!=0) {
                    System.out.println("Album inserido com sucesso no banco!");
		} else {
                    System.out.println("Erro na inserção do Album!");
		}
                // inserindo outra musica;
                Musica y2 = new Musica("metade de mim", 260, 10);
               
		if(Conexao.inserirmusica(y2)!=0) {
                    System.out.println("Musica inserida com sucesso no banco!");
		} else {
                    System.out.println("Erro na inserção!");
		}
                /*
                /*
		//Exemplo de atualização da Musica no SGBD, buscando-a pelo nome atual!!!
		y.setNota(10);
		String nome = y.getNomemusica();
		y.setNomemusica("Continuar");
		if(Conexao.atualizar(y, nome)!=0) {
                   
			System.out.println("Música atualizada com sucesso no banco!");
		} else {
			System.out.println("Erro na atualização!");
		}
		
		//Exemplo de listagem de todas Musicas do SGBD
	*/
		ResultSet res = Conexao.relatorioCompleto();
                System.out.println("Relatório Musica: ");
		if(res!=null) {
			try {
                            while(res.next()) {
				System.out.println("....Musica: "+res.getString("musica.nome"));
				System.out.println("...Artista: "+res.getString("artista.nome"));
				System.out.println(".....Album: "+res.getString("album.nome"));
                                System.out.println("....Genero: "+res.getString("genero.nome"));
				System.out.println("==========");
                            }
			} catch (SQLException e) {
				System.out.println("Problema para exibir registros!");
			}
		} else {
			System.out.println("A pesquisa não retornou nenhum registro!");
                }
              
        // LISTAGEM DE TODOS OS ALBUNS DO BANCO
                ResultSet resal = Conexao.relatorioalbum();
                System.out.println("Relatório Album: ");
		if(resal!=null) {
			try {
                            while(resal.next()) {
                                System.out.println("........Id: "+resal.getInt("id"));
				System.out.println("......Nome: "+resal.getString("nome"));
				System.out.println("...Artista: "+resal.getInt("artista_id"));
				System.out.println(".......Ano: "+resal.getInt("ano"));
				System.out.println("xxxxxxxxxxxxxxxxxxxxxxxxx\n");
                            }
			} catch (SQLException e) {
				System.out.println("Problema para exibir registros!");
			}
		} else {
			System.out.println("A pesquisa não retornou nenhum registro!");
                }
                
                
                // LISTAGEM DE TODOS OS ARTISTAS;
                ResultSet resart = Conexao.relatorioArtista();
                System.out.println("\nRelatório Artista:");
		if(resart!=null) {
			try {
                            while(resart.next()) {
                                System.out.println("........Id: "+resart.getInt("id"));
				System.out.println("......Nome: "+resart.getString("nome"));
				System.out.println("...Genero Id: "+resart.getInt("genero_id"));
				System.out.println("xxxxxxxxxxxxxxxxxxxxxxxxx");
                            }
			} catch (SQLException e) {
				System.out.println("Problema para exibir registros!");
			}
		} else {
			System.out.println("A pesquisa não retornou nenhum registro!");
                }   
        
                // relatorio de todos os generos
                ResultSet resge = Conexao.relatorioGenero();
                System.out.println("\nRelatório Genero:");
		if(resge!=null) {
			try {
                            while(resge.next()) {
                                System.out.println("........Id: "+resge.getInt("id"));
				System.out.println("......Nome: "+resge.getString("nome"));
				System.out.println("xxxxxxxxxxxxxxxxxxxxxxxxx");
                            }
			} catch (SQLException e) {
				System.out.println("Problema para exibir registros!");
			}
		} else {
			System.out.println("A pesquisa não retornou nenhum registro!");
                }     
		
                // pesquisa musica
                nomemusica = JOptionPane.showInputDialog("Nome da Música para Pesquisa: ");
                ResultSet res1 = (ResultSet) Conexao.pesqMusica(nomemusica);
                if(res1!=null) {
                    try {
                        while(res1.next()) {
                            System.out.println("Música Pesquisada");
                            System.out.println("Nome: "+res1.getString("nome"));
                            System.out.println("Duraçãoo: "+res1.getInt("duracao"));
                            System.out.println("Nota: "+res1.getInt("nota"));
                            System.out.println("xxxxxxxxxxxxxxxxxxxxxxxxx");
                            System.out.println("");
                        }
                    } catch (SQLException e) {
                            System.out.println("Problema para exibir registros!");
                    }
                } else {
			System.out.println("A pesquisa nÃo retornou nenhum registro!");
		}
                
                // pesquisa album
                nomeAlbum = JOptionPane.showInputDialog("Nome do Album para Pesquisa: ");
                ResultSet res2 = (ResultSet) Conexao.pesqAlbum(nomeAlbum);
                if(res2!=null) {
                    try {
                        while(res2.next()) {
                            System.out.println("Album Pesquisado");
                            System.out.println("........Id: "+res2.getInt("id"));
                            System.out.println("......Nome: "+res2.getString("nome"));
                            System.out.println("...Artista: "+res2.getInt("artista_id"));
                            System.out.println(".......Ano: "+res2.getInt("ano"));
                            System.out.println("xxxxxxxxxxxxxxxxxxxxxxxxx");
                            System.out.println("");
                        }
                    } catch (SQLException e) {
                            System.out.println("Problema para exibir registros!");
                        }
                } else {
			System.out.println("A pesquisa nÃo retornou nenhum registro!");
		}
               
                 // pesquisa Artista
                nomeArtista = JOptionPane.showInputDialog("Nome do Artista para Pesquisa: ");
                ResultSet res3 = (ResultSet) Conexao.pesqArtista(nomeArtista);
                if(res3!=null) {
                    try {
                        while(res3.next()) {
                            System.out.println("Artista Pesquisado!");
                            System.out.println("........Id: "+res3.getInt("id"));
                            System.out.println("......Nome: "+res3.getString("nome"));
                            System.out.println("...Genero Id: "+res3.getInt("genero_id"));
                            System.out.println("xxxxxxxxxxxxxxxxxxxxxxxxx");
                            System.out.println("");
                        }
                    } catch (SQLException e) {
                            System.out.println("Problema para exibir registros!");
                        }
                } else {
			System.out.println("A pesquisa nÃo retornou nenhum registro!");
		}
               
                   
                // pesquisa Gênero
                nomeGenero = JOptionPane.showInputDialog("Nome do Gênero para Pesquisa: ");
                ResultSet res4 = (ResultSet) Conexao.pesqGenero(nomeGenero);
                if(res4!=null) {
                    try {
                        while(res4.next()) {
                            System.out.println("Gênero Pesquisado");
                            System.out.println("........Id: "+res4.getInt("id"));
                            System.out.println("......Nome: "+res4.getString("nome"));
                            System.out.println("xxxxxxxxxxxxxxxxxxxxxxxxx");
                            System.out.println("");
                        }
                    } catch (SQLException e) {
                            System.out.println("Problema para exibir registros!");
                        }
                } else {
			System.out.println("A pesquisa nÃo retornou nenhum registro!");
		}
                
	}
           
}
