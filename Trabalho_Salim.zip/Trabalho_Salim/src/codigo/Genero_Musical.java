/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package codigo;

//import java.util.ArrayList;

/**
 *
 * @author MÁYRA NUNES
 */
public class Genero_Musical {
    
    private String nomeGenero;
    private int id;
   
    public Genero_Musical(String nomeGenero) {
        this.nomeGenero = nomeGenero;
        
    }    

    public String getNomeGenero() {
        return nomeGenero;
    }

    public void setNomeGenero(String nomeGenero) {
        this.nomeGenero = nomeGenero;
    }
   
    public void exibeGenero(){
        System.out.println("Nome Genero: "+nomeGenero);
    }
    
}
