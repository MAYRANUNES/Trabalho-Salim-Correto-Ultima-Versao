/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package codigo;

import java.util.ArrayList;

/**
 *
 * @author MÁYRA NUNES
 */
public class Artista {
    
    private String nomeArtista;
    private int genero_id;
    private ArrayList <Album> listaAlbum;
    
    

    public Artista(String nomeArtista) {
        this.nomeArtista = nomeArtista;
        listaAlbum= new ArrayList();
        
    }

    public int getGenero_id() {
        return genero_id;
    }

    public void setGenero_id(int genero_id) {
        this.genero_id = genero_id;
    }
    
    public ArrayList<Album> getListaAlbum() {
        return listaAlbum;
    }

    public void setListaAlbum(ArrayList<Album> listaAlbum) {
        this.listaAlbum = listaAlbum;
    }
    
    public String getNomeArtista() {
        return nomeArtista;
    }

    public void setNomeArtista(String nomeArtista) {
        this.nomeArtista = nomeArtista;
    }

    public void exibeArtista(){
        System.out.println("\nArtista: "+this.nomeArtista);
        for(int i=0;i<listaAlbum.size();i++){
                       
            listaAlbum.get(i).exibeAlbum();
           
        }
        
        
    }
  
}
