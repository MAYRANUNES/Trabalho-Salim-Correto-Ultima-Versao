/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package codigo;

import java.util.ArrayList;

/**
 *
 * @author MÁYRA NUNES
 */
public class Album {
    private String nomeAlbum;
    private int anoLancamento;
    private int artista_id;
    private ArrayList <Musica> listaMusical;

    public Album(String nomeAlbum, int anoLancamento) {
        this.nomeAlbum = nomeAlbum;
        this.anoLancamento = anoLancamento;
        listaMusical= new ArrayList();
    }

    
    
    public int getArtista_id() {
        return artista_id;
    }

    public void setArtista_id(int artista_id) {
        this.artista_id = artista_id;
    }
    
    public String getNomeAlbum() {
        return nomeAlbum;
    }

    public void setNomeAlbum(String nomeAlbum) {
        this.nomeAlbum = nomeAlbum;
    }

    public ArrayList<Musica> getListaMusical() {
        return listaMusical;
    }

    public void setListaMusical(ArrayList<Musica> listaMusical) {
        this.listaMusical = listaMusical;
    }
    
    public int getAnoLancamento() {
        return anoLancamento;
    }

    public void setAnoLancamento(int anoLancamento) {
        this.anoLancamento = anoLancamento;
    }
    
    public void exibeAlbum(){
        System.out.println("Album: "+nomeAlbum+"\nAno Lançamento: "+anoLancamento);
        
        for(int i=0;i<listaMusical.size();i++){
            listaMusical.get(i).exibeMusica();
        }
    }
    
}
